<?php

/*
 *  CONFIGURE EVERYTHING HERE
 */

// an email address that will be in the From field of the email.
$from = 'ENREGISTREMENT EN LIGNE <registration@algorithme.cm>';

// an email address that will receive the email with the output of the form
$sendTo = 'IFPIA <registration@algorithme.cm>';

// subject of the email
$subject = 'NOUVEL ENREGISTREMENT EN LIGNE';

// form field names and their translations.
// array variable name => Text to appear in the email
$fields = array('name' => 'Nom & Prénom', 'birth_date' => 'Date de naissance', 'cni_number' => 'N° de CNI', 'phone_number' => 'Numéro WhatsApp', 'country' => 'Pays', 'town' => 'Ville', 'tutor' => 'Nom & Prénom du Tuteur', 'tutor_work' => 'Occupation du Tuteur', 'tutor_phone_number' => 'Numéro WhatsApp du Tuteur', 'ifpia_visit_reason' => 'Raison de la visite', 'ifpia_study_reason' => 'Raison du choix de IFPIA', 'check_moy_12' => 'J\'accepte que l\'étudiant redouble s\'il n\'a pas 12 de
                      moyenne', 'check_viable_project' => 'J\'accepte que l\'étudiant redouble s\'il n\'a pas un projet
                      viable pour la soutenance', 'check_discipline' => 'J\'accepte que l\'étudiant redouble s\'il n\'est pas
                      discipliné', 'email' => 'Email', 'today_date' => 'Date du jour', 'actual_time' => 'Heure', 'check_data_usage' => 'Je confirme exactes les informations que j\'ai fournies et
                      autorise IFPIA à l\'utiliser à sa guise');

// message that will be displayed when everything is OK :)
$okMessage = 'Thank you for registering. We hope to see you very soon !';

// If something goes wrong, we will display this message.
$errorMessage = 'An error has occurred. Try Again.';

/*
 *  LET'S DO THE SENDING
 */

// if you are not debugging and don't need error reporting, turn this off by error_reporting(0);
error_reporting(E_ALL & ~E_NOTICE);

try {

    if (count($_POST) == 0)
        throw new \Exception('Form is empty');

    $emailText = "Vous avez un nouvel enregistrement chez IFPIA\n=============================\n";

    foreach ($_POST as $key => $value) {
        // If the field exists in the $fields array, include it in the email
        if (isset($fields[$key])) {
            $emailText .= "$fields[$key]: $value\n";
        }
    }

    // All the neccessary headers for the email.
    $headers = array('Content-Type: text/plain; charset="UTF-8";',
        'From: ' . $from,
        'Reply-To: ' . $from,
        'Return-Path: ' . $from,
    );

    // Send email
    mail($sendTo, $subject, $emailText, implode("\n", $headers));

    $responseArray = array('type' => 'success', 'message' => $okMessage);
} catch (\Exception $e) {
    $responseArray = array('type' => 'danger', 'message' => $errorMessage);
}


// if requested by AJAX request return JSON response
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
    $encoded = json_encode($responseArray);

    header('Content-Type: application/json');

    echo $encoded;
}
// else just display the message
else {
    echo $responseArray['message'];
}